# CBT SMKN 14 Beta — Browser Shell

**Versi:** 0.1.0-beta  
**Application ID:** `id.sch.smkn14kabupatentangerang.cbtbeta`

Ini adalah proyek Android Studio baru sebagai titik awal beta. Aplikasi berfungsi sebagai browser sederhana berbasis Android WebView untuk membuka website CBT sekolah.

## Yang tersedia

- Halaman beranda dengan pintasan Portal Siswa dan Portal Guru/Proktor.
- Kolom alamat untuk membuka URL atau melakukan pencarian Google.
- Navigasi kembali, maju, muat ulang, dan beranda.
- Dukungan JavaScript, penyimpanan web, cookie, unggah file dari halaman web, dan unduhan.
- Status bar Android dan navigation bar tetap normal.

## Yang sengaja tidak disertakan

- Tidak ada kiosk mode atau `LockTask`.
- Tidak ada screen pinning yang dimulai oleh aplikasi.
- Tidak ada pemblokiran screenshot (`FLAG_SECURE`).
- Tidak ada PIN proktor atau dialog keluar khusus.
- Tidak ada pembatasan domain/allowlist.
- Tidak ada deteksi perpindahan aplikasi atau penguncian tombol Back.

Pengaturan keamanan jaringan standar Android/WebView tetap digunakan; proyek tidak mengaktifkan HTTP cleartext atau mixed content. Ini bukan aplikasi pengunci ujian, melainkan shell browser beta.

## Alamat website yang digunakan

- Portal Siswa: `https://cbt.smkn14kabupatentangerang.sch.id/siswa/login.php`
- Portal Guru/Proktor: `https://cbt.smkn14kabupatentangerang.sch.id/admin/login.php`
- Beranda domain: `https://cbt.smkn14kabupatentangerang.sch.id/`

Alamat tersebut diambil dari URL yang ditemukan pada APK yang dikirim. Pintasan bisa diubah di `MainActivity.kt`.

## Membuka dan membangun di Android Studio

1. Ekstrak ZIP proyek ini.
2. Buka Android Studio, pilih **Open**, lalu pilih folder `CBT_SMKN14_Beta`.
3. Pastikan Android SDK Platform 35 dan JDK 17 tersedia.
4. Proyek menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21, dan Gradle 8.9. Arsip ini tidak menyertakan `gradle-wrapper.jar`. Bila Android Studio meminta wrapper, jalankan `gradle wrapper --gradle-version 8.9` dari folder proyek menggunakan instalasi Gradle lokal. Alternatifnya, buat proyek **Empty Views Activity** baru di Android Studio lalu salin isi folder `app/src/main` serta konfigurasi Gradle dari template ini.
5. Sinkronkan Gradle, jalankan ke perangkat untuk pengujian, atau pilih **Build > Build APK(s)**.

Folder ini berisi source project, bukan APK siap instal. APK dapat dibangun dari Android Studio setelah Gradle dan Android SDK tersinkron.

## Identitas aplikasi

Application ID beta dibuat berbeda dari APK lama agar keduanya dapat dipasang berdampingan di satu perangkat. Nama aplikasi yang tampil adalah **CBT SMKN 14 Beta**.

## File utama

- `app/src/main/java/.../MainActivity.kt` — UI browser dan logika WebView.
- `app/src/main/AndroidManifest.xml` — deklarasi aplikasi dan izin internet.
- `app/build.gradle.kts` — versi dan konfigurasi build.
