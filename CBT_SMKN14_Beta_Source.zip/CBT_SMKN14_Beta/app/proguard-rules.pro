# No custom shrinking rules are needed for this beta browser shell.
