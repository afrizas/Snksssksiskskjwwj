package id.sch.smkn14kabupatentangerang.cbtbeta

import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * CBT SMKN 14 Exambrowser — Beta 0.2.1
 * A focused school-portal app, not a general-purpose browser UI.
 * Kiosk mode, LockTask, proctor PIN, screenshot blocking and device locking
 * are intentionally not included in this beta.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var homePanel: View
    private lateinit var pageTitle: TextView
    private lateinit var progressBar: ProgressBar
    private var uploadCallback: ValueCallback<Array<Uri>>? = null

    private val studentUrl = "https://cbt.smkn14kabupatentangerang.sch.id/siswa/login.php"
    private val staffUrl = "https://cbt.smkn14kabupatentangerang.sch.id/admin/login.php"
    private val fileChooserRequest = 2407

    // These two identification values were found in the school's previous APK.
    // They let the CBT website recognize its app client; they do NOT activate kiosk mode.
    private val appUserAgent = "CBT-SMKN14-Exambro/3.0 (Android; KioskLock)"
    private val appHeaders = mapOf("X-CBT-SMKN14-App" to "SMKN14-Verified")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 33, 61)
        window.navigationBarColor = Color.rgb(16, 33, 61)
        window.decorView.systemUiVisibility = 0
        buildInterface()
        setupWebView()
        showPortalHome()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(244, 247, 252))
        }

        val appBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(11), dp(18), dp(11))
            setBackgroundColor(Color.rgb(16, 33, 61))
        }
        val badge = ImageView(this).apply {
            setImageResource(R.drawable.logo_smkn14)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = rounded(Color.WHITE, 13)
            contentDescription = "Logo SMK Negeri 14 Kabupaten Tangerang"
            layoutParams = LinearLayout.LayoutParams(dp(45), dp(45))
        }
        val titleColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleColumn.addView(TextView(this).apply {
            text = "CBT SMKN 14"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        pageTitle = TextView(this).apply {
            text = "EXAMBROWSER BETA  •  v0.2.1"
            textSize = 10f
            letterSpacing = 0.06f
            setTextColor(Color.rgb(180, 198, 225))
            setPadding(0, dp(2), 0, 0)
        }
        titleColumn.addView(pageTitle)
        appBar.addView(badge)
        appBar.addView(titleColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(appBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(70)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(37, 99, 235))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(222, 229, 239))
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        val content = FrameLayout(this)
        webView = WebView(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.WHITE)
        }
        homePanel = createPortalHome()
        content.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        content.addView(homePanel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        root.addView(content, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun createPortalHome(): View {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(244, 247, 252))
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(28))
        }
        column.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo_smkn14)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Lambang SMK Negeri 14 Kabupaten Tangerang"
            layoutParams = LinearLayout.LayoutParams(dp(132), dp(132)).apply {
                gravity = Gravity.CENTER
                bottomMargin = dp(14)
            }
        })
        column.addView(TextView(this).apply {
            text = "PORTAL CBT SMKN 14"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(37, 99, 235))
        })
        column.addView(TextView(this).apply {
            text = "KABUPATEN TANGERANG"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.04f
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, dp(3), 0, dp(22))
        })
        column.addView(TextView(this).apply {
            text = "Pilih portal untuk melanjutkan. Halaman CBT akan dibuka langsung di dalam aplikasi."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, 0, 0, dp(20))
        })
        column.addView(portalCard(
            symbol = "S",
            title = "Portal Siswa",
            description = "Masuk untuk melihat jadwal dan mengerjakan ujian.",
            onClick = { openPortal(studentUrl, "PORTAL SISWA") }
        ))
        column.addView(portalCard(
            symbol = "G",
            title = "Portal Guru / Proktor",
            description = "Masuk ke halaman pengelolaan CBT sekolah.",
            onClick = { openPortal(staffUrl, "PORTAL GURU / PROKTOR") }
        ), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })

        column.addView(TextView(this).apply {
            text = "CBT SMKN 14 Kabupaten Tangerang\nAplikasi beta 0.2.0"
            textSize = 12f
            setTextColor(Color.rgb(125, 139, 159))
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        })
        scroll.addView(column)
        return scroll
    }

    private fun portalCard(symbol: String, title: String, description: String, onClick: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(17), dp(16), dp(17))
            background = rounded(Color.WHITE, 18)
            isClickable = true
            isFocusable = true
            elevation = dp(2).toFloat()
            setOnClickListener { onClick() }
        }
        card.addView(TextView(this).apply {
            text = symbol
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(37, 99, 235), 14)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        })
        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), 0, dp(4), 0)
        }
        details.addView(TextView(this).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(27, 42, 65))
        })
        details.addView(TextView(this).apply {
            text = description
            textSize = 12f
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, dp(4), 0, 0)
        })
        card.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(TextView(this).apply {
            text = "›"
            textSize = 28f
            setTextColor(Color.rgb(148, 163, 184))
        })
        return card
    }

    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.allowFileAccess = false
        settings.allowContentAccess = true
        settings.setGeolocationEnabled(false)
        settings.userAgentString = appUserAgent

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") {
                    // Re-attach the CBT app marker to top-level page navigations.
                    if (request.isForMainFrame) view.loadUrl(uri.toString(), appHeaders)
                    return request.isForMainFrame
                }
                return openExternalScheme(uri)
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                val uri = Uri.parse(url)
                val scheme = uri.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") {
                    view.loadUrl(url, appHeaders)
                    return true
                }
                return openExternalScheme(uri)
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                homePanel.visibility = View.GONE
                webView.visibility = View.VISIBLE
                progressBar.visibility = View.VISIBLE
                progressBar.progress = 5
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                uploadCallback?.onReceiveValue(null)
                uploadCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(intent, fileChooserRequest)
                    true
                } catch (_: ActivityNotFoundException) {
                    uploadCallback?.onReceiveValue(null)
                    uploadCallback = null
                    Toast.makeText(this@MainActivity, "Tidak ada aplikasi pemilih file.", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }

        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val uri = Uri.parse(url)
                if (uri.scheme != "https") {
                    Toast.makeText(this, "Unduhan harus menggunakan HTTPS.", Toast.LENGTH_SHORT).show()
                    return@DownloadListener
                }
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(uri)
                    .setTitle(fileName)
                    .setDescription("Mengunduh dari CBT SMKN 14")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    .addRequestHeader("X-CBT-SMKN14-App", "SMKN14-Verified")
                request.addRequestHeader("User-Agent", appUserAgent)
                val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                manager.enqueue(request)
                Toast.makeText(this, "Unduhan dimulai. Cek folder Downloads.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal mengunduh: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun openExternalScheme(uri: Uri): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka tautan ini.", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun openPortal(url: String, title: String) {
        pageTitle.text = title
        homePanel.visibility = View.GONE
        webView.visibility = View.VISIBLE
        progressBar.visibility = View.VISIBLE
        webView.loadUrl(url, appHeaders)
    }

    private fun showPortalHome() {
        webView.stopLoading()
        webView.visibility = View.GONE
        homePanel.visibility = View.VISIBLE
        progressBar.visibility = View.GONE
        pageTitle.text = "EXAMBROWSER BETA  •  v0.2.1"
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        when {
            webView.visibility == View.VISIBLE && webView.canGoBack() -> webView.goBack()
            webView.visibility == View.VISIBLE -> showPortalHome()
            else -> super.onBackPressed()
        }
    }

    @Deprecated("Activity result callback for WebView file uploads")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequest) {
            val result = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }

    override fun onDestroy() {
        uploadCallback?.onReceiveValue(null)
        uploadCallback = null
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.destroy()
        }
        super.onDestroy()
    }
}
