# No custom obfuscation rules are required for this beta build.
