plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.sch.smkn14kabupatentangerang.cbtbeta"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.sch.smkn14kabupatentangerang.cbtbeta"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "0.2.1-beta"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
