# CBT SMKN 14 Exambrowser Beta 0.2.1

Proyek Android Studio untuk aplikasi portal CBT sekolah. Tampilan browser umum (kolom URL, tombol maju/mundur, tombol beranda) sudah dihilangkan. Aplikasi menampilkan pilihan Portal Siswa dan Portal Guru/Proktor, lalu membuka halaman login di dalam WebView.

## Perubahan dibanding Beta 0.1.0

- UI browser umum dihapus: tidak ada address bar, tombol maju/mundur, dan kolom alamat.
- Aplikasi dibuka sebagai portal CBT dengan pilihan Siswa dan Guru/Proktor.
- WebView tetap dipakai di belakang layar untuk menampilkan website CBT; ini normal untuk aplikasi Android yang membungkus portal web.
- Mengirim User-Agent aplikasi dan header `X-CBT-SMKN14-App` yang ditemukan pada APK lama agar server dapat mengenali klien aplikasi.
- Tetap tidak menyertakan Kiosk Mode, LockTask, PIN proktor, pemblokiran screenshot, atau pengelolaan perangkat.
- Menyediakan cookie, JavaScript, penyimpanan web, upload file, dan unduhan HTTPS.

## Identitas aplikasi

- Application ID: `id.sch.smkn14kabupatentangerang.cbtbeta`
- Version: `0.2.1-beta` (versionCode 3)
- Minimum Android: 6.0 (API 23)
- Compile/Target SDK: 35

## Build

Buka folder proyek ini di Android Studio, tunggu Gradle Sync, lalu pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Proyek membutuhkan JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3, Kotlin 2.0.21 dan Gradle 8.9.

## Catatan penting soal pesan "Akses Browser Biasa Ditutup"

APK lama memuat dua identitas klien berikut:

- User-Agent: `CBT-SMKN14-Exambro/3.0 (Android; KioskLock)`
- Header: `X-CBT-SMKN14-App: SMKN14-Verified`

Beta 0.1.0 tidak mengirim identitas tersebut sehingga halaman server kemungkinan menganggapnya sebagai browser biasa. Beta 0.2.0 mengirimkannya saat membuka halaman dan saat navigasi halaman utama.

Header dan User-Agent hanya penanda yang dikirim klien; keduanya bukan autentikasi atau bukti keamanan. Karena User-Agent lama mengandung teks `KioskLock`, teks tersebut dipertahankan hanya untuk kompatibilitas sementara, tetapi fitur kiosk/LockTask tidak diaktifkan di aplikasi ini. Untuk rilis resmi, sebaiknya backend mengizinkan identifier Beta yang baru dan menggunakan autentikasi server yang sebenarnya.

Jika pesan blokir masih muncul setelah build 0.2.0, pemeriksaan lain kemungkinan ada di backend PHP (misalnya pemeriksaan session, referer, JavaScript bridge, atau nama header lain). Perlu memeriksa kode PHP yang menampilkan pesan tersebut; jangan mengubah atau menonaktifkan pemeriksaan server secara membabi buta.


## Logo sekolah (Beta 0.2.1)

- Logo SMK Negeri 14 Kabupaten Tangerang ditambahkan ke bagian atas halaman beranda aplikasi.
- Logo juga digunakan pada bagian kiri header aplikasi.
- Ikon launcher Android menggunakan logo sekolah yang sama.
- File gambar berada di `app/src/main/res/drawable-nodpi/logo_smkn14.jpg`.
